import React, {useRef} from "react";
import "./App.css";

function App(){
  const nameRef = useRef();
  const emailRef = useRef();
  const passwordRef = useRef();
  const confirmPasswordRef = useRef();


const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit = (e) =>{
    e.preventDefault();

    const name = nameRef.current.value;
    const email = emailRef.current.value;
    const password = passwordRef.current.value;
    const confirmPassword = confirmPasswordRef.current.value;

    if(!name.trim()){
      alert("name is required");
      return;
    }
    if(!email.trim()){
      alert("email is required");
      return;
    }
    if(!validateEmail(email)){
      alert("please enter a validate Email");
      return;
    }
    if(!password || !confirmPassword){
      alert("password fields cannot be empty");
      return;
    }
    if(password !== confirmPassword){
      alert("password do not match");
      return;
    }
    alert(
      `Registration Successful!\n\nName: ${name}\nEmail: ${email}`
    );

    console.log("registered user data:", {
      name, 
      email,
      password,
      confirmPassword,
    });


    nameRef.current.value = "";
    emailRef.current.value = "";
    passwordRef.current.value = "";
    confirmPasswordRef.current.value = "";
  };

  return(
    <div className="container">
      <div className="form-box">
        <h2>Registration Form</h2>

        <form onSubmit={handleSubmit}>
          <input type="text" placeholder="Enter Name" ref={nameRef} />
          <input type="email" placeholder="Enter Email" ref={emailRef} />
          <input type="password" placeholder="Enter Password" ref={passwordRef} />
          <input type="password" placeholder="enter Confirm password" ref={confirmPasswordRef} />

          <button type="submit">Register</button>
        </form>
      </div>
    </div>
  );
}
  export default App;


  