import React, { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

const ThemedComponent = () => {
  const { theme } = useContext(ThemeContext);

  return (
    <div className="theme-box">
      <h2>Current Theme</h2>
      <p>{theme.toUpperCase()} MODE</p>
    </div>
  );
};

export default ThemedComponent;
