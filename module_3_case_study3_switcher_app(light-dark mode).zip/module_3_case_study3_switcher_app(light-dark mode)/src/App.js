import React, { useContext } from "react";
import { ThemeProvider, ThemeContext } from "./context/ThemeContext";
import ThemeSwitcher from "./components/ThemeSwitcher";
import ThemedComponent from "./components/ThemedComponent";
import "./App.css";

const AppContent = () => {
  const { theme } = useContext(ThemeContext);

  return (
    <div className={`app ${theme}`}>
      <h1 className="title">Theme Switcher App</h1>
      <ThemeSwitcher />
      <ThemedComponent />
    </div>
  );
};

const App = () => {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
};

export default App;
