import { useParams, Link } from "react-router-dom";
import { users, posts } from "./data";
import { useState } from "react";

function UserPosts() {
  const { id } = useParams();
  const user = users.find((u) => u.id === Number(id));
  const userPosts = posts.filter((p) => p.userId === Number(id));
  const [selectedPost, setSelectedPost] = useState(null);

  // If user not found
  if (!user) {
    return <h2>No user found</h2>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <h2>{user.name}'s Posts</h2>

      {/* If no posts */}
      {userPosts.length === 0 && <p>No post found for current user</p>}

      {/* Post titles */}
      <ul>
        {userPosts.map((post) => (
          <li key={post.id}>
            <Link onClick={() => setSelectedPost(post)}>
              {post.title}
            </Link>
          </li>
        ))}
      </ul>

      {/* Selected post display */}
      {selectedPost && (
        <div>
          <h3>{selectedPost.title}</h3>
          <p>{selectedPost.body}</p>
        </div>
      )}

      <br />
      <Link to="/">⬅ Back to Users</Link>
    </div>
  );
}

export default UserPosts;
