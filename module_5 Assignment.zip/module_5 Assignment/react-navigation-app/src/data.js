// Users data
export const users = [
  { id: 1, name: "Seema" },
  { id: 2, name: "Ashish" },
  { id: 3, name: "Prisha" }
];

// Posts data
export const posts = [
  { id: 1, userId: 1, title: "React Basics", body: "React introduction" },
  { id: 2, userId: 1, title: "React Router", body: "Navigation in React" },
  { id: 3, userId: 2, title: "JavaScript", body: "JS fundamentals" }
];
