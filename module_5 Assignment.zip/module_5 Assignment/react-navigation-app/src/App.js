import { BrowserRouter, Routes, Route } from "react-router-dom";
import Users from "./Users";
import UserPosts from "./UserPosts";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Users />} />
        <Route path="/user/:id" element={<UserPosts />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
