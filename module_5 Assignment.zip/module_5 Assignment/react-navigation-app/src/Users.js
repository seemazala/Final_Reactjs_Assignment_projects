import { Link } from "react-router-dom";
import { users } from "./data";

function Users() {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Users List</h2>

      {users.map((user) => (
        <p key={user.id}>
          <Link to={`/user/${user.id}`}>{user.name}</Link>
        </p>
      ))}
    </div>
  );
}

export default Users;
