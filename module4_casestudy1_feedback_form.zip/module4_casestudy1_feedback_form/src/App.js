import React, {useState} from 'react';
import './App.css';

function App() {

  const [formData, setFormData] = useState({
      name : "",
      email : "",
      subject : "",
      feedback : "",

  });

  const handleChange = (e) => {
    const {name , value} = e.target;
    setFormData({...formData, [name] : value});
  };

  const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit=(e) => {
    e.preventDefault();

    if(!formData.name.trim()){
      alert("name is required");
      return;
    }

    if(!formData.email.trim()){
      alert("email is required");
      return;
    }

     if (!validateEmail(formData.email)) {
      alert("Enter a valid email address");
      return;
    }

    alert(
      `Name: ${formData.name}\nEmail: ${formData.email}\nSubject: ${formData.subject}\nFeedback: ${formData.feedback}`
    );

    console.log("submitted feedback data: ", formData);

    setFormData({
      name : "",
      email : "",
      subject : "",
      feedback : "",
    });
  };
  return (
    
    <div className="container">
      <div className="image-section">
      <div className="form-section">
        <h2>Feedback</h2>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
          />

          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
          />

          <input
            type="text"
            name="subject"
            placeholder="Subject"
            value={formData.subject}
            onChange={handleChange}
          />

          <textarea
            name="feedback"
            placeholder="Feedback"
            value={formData.feedback}
            onChange={handleChange}
          ></textarea>
          <button type="submit">Submit</button>
        </form>
      </div>

     
        
      </div>
      
    </div>
  );
}

export default App;
    
  