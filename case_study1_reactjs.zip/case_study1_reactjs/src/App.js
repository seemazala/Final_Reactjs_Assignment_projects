import React,{useState} from 'react';
import './App.css';

function App() {
  const employees = [
    {id: 1, name: "ashish", department: "tech", position:"software Engineer"},
    {id: 2, name: "seema", department: "HR", position: "HR manager"},
    {id: 3, name: "prisha", department: "tech", position: "Devops Engineer"},
    {id: 4, name: "dwira", department: "Finance", position: "Accountant"},
    {id: 5, name: "krishita", department: "tech", position: "backend developer"},
  ];

  const [filter, setFilter] = useState("All");

  const filteredEmployee = filter === "All" ? employees : employees.filter((emp) => emp.department === filter);
  
  return (
      <div className='container'>
        <h2>Welcome Employee Data</h2>
        <select className='dropdown' value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="ALL">All</option>
          <option value="tech">tech</option>
          <option value="HR">HR</option>
          <option value="Finance">Finance</option>

        </select>

        <table className='emp-table'>
          <thead>
            <tr>
              <th>No</th>
              <th>Name</th>
              <th>Department</th>
              <th>Position</th>
            </tr>
          </thead>

          <tbody>
            {filteredEmployee.map((emp, index) => (
              <tr key = {emp.id}>
                <td>{String(index + 1).padStart(2, "0")}</td>

                <td>{emp.name}</td>
                <td>{emp.department}</td>
                <td>{emp.position}</td>
              </tr>
            ))}

            {Array.from({length : 10}).map((_, i) => (
              <tr key  = {"empty" + i}>
                 <td></td><td></td><td></td><td></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
  );
}

export default App;
