import React from 'react';
import Counter from './Counter1';

//import Counter from './../Counter';
import './style.css';

function App() {
  return (
   <div className='app'>
    <h1 className='title'>Counter Application</h1>
    <Counter />
   </div>
  );
}

export default App;
