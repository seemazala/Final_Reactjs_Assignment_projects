import React , {Component} from "react";

class Counter extends Component{
    constructor(){
        super();
        this.state = {
            count :0
        };
    }
    componentDidMount(){
        console.log("counter Component Mounted");
    }
    increament = () =>{
        this.setState({count: this.state.count + 1});
    };

    decreament = () => {
        this.setState({count: this.state.count - 1});
    };
    reset = () => {
        this.setState({count : 0});
    };
    render(){
        return (
            <div className="counter-box">
                <p className="counter-value">{this.state.count}</p>

                <div className="btn-group">
                    <button className="btn inc" onClick={this.increament}>Increament</button>
                    <button className="btn dec" onClick={this.decreament}>Decreament</button>
                    <button className="btn reset" onClick={this.reset}>Reset</button>
                </div>
            </div>
        );
    }
}

export default Counter;