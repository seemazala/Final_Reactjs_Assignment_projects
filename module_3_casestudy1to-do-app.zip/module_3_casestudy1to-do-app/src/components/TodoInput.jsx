import React, {useState} from "react";

function TodoInput({ addTodo }){
    const [input, setInput] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        addTodo(input);
        setInput("");
    };

    return(
        <form onSubmit={handleSubmit} className="todo-input" >
            <input type="text" placeholder="add to a new task..." value={input}
            onChange={(e) => setInput(e.target.value)}></input>
            <button type="submit">ADD</button>
        </form>
    );
}

export default TodoInput;