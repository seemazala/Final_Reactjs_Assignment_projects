import React from 'react';

function TodoList({todos,toggleComplete, removeTodo}){
    return(
        <div className='todo-list'>
            {todos.length === 0 && <p className='empty'>No Task Adeed yet.</p>}

            {todos.map((todo) => (
                <div key={todo.id} className='todo-item'>
                    <span onClick={() => toggleComplete(todo.id)}
                    className={todo.completed ? "completed" : ""}>{todo.text}
                    </span>
                    <button className='remove' onClick={() => removeTodo(todo.id)}>
                    Remove
                    </button>

                </div>
            ))}
        </div>
    );
}
 export default TodoList;