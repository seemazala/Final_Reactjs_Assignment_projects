import React,{useState, useEffect} from "react";
const Weather = () => {
    const [city, setCity] = useState("");
    const [searchCity, setSearchCity] = useState ("delhi");
    const [weather, setWeather] = useState(null);

    const API_KEY = "1e239bfb9ab65fa54ed647db4cee046f";

    useEffect(() => {
        fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${searchCity}&units=metric&appid=${API_KEY}`
         )

         .then((res) => res.json())
         .then((data) => setWeather(data))
         .catch((error) => console.error(error));
    }, [searchCity]);

    const handleSearch = () =>{
        if(city.trim() !== ""){
            setSearchCity(city);
            setCity("");
        }
    };

    return(
        <div className="weather-card">
            <div className="search">
                <input type="text" placeholder="Enter City Name" value={city} 
                onChange={(e) => setCity(e.target.value)}></input>
                <button onClick={handleSearch}>Search</button>
            </div>

            {weather && weather.main && (
                <div className="weather-info">
                    <h2>{weather.name}</h2>
                    <p className="temp">{weather.main.temp}°C</p>
                    <p>{weather.weather[0].main}</p>
                    <p>Humidity: {weather.main.humidity}%</p>
                    <p>Wind : {weather.wind.speed}Km/h</p>
                </div>
            )}
        </div>
    );
};


export default Weather;
