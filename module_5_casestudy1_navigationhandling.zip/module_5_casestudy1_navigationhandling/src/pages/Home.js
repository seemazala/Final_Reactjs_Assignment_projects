import React from "react";

function Home() {
  return (
    <div className="page">
      <h1>Welcome to React Navigation App</h1>
      <p>This is the Home Page</p>
    </div>
  );
}

export default Home;
