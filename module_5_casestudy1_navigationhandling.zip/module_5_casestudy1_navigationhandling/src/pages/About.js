import React from "react";

function About() {
  return (
    <div className="page">
      <h1>About</h1>
      <p>This application is created using React Router DOM.</p>
    </div>
  );
}

export default About;
