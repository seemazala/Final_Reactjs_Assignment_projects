import React from "react";
import star from "./icon/star.png";
import heart from "./icon/heart.png";

function Product({name, price, description, img , reviews = 325}){
    return(
        <div className="product-card">

        <div className="icons">
        <img src={heart} className="icon" alt="like" />
        
        </div>

            <img src={img}  alt="name" className="product-img"></img>
            <h3 className="product-name">{name}</h3>
            <p className="product-price">${price}</p>
            <p className="product-desc">{description}</p>

         <div className="rating-row">
        <img src={star} className="star" alt="rating" />
        <img src={star} className="star" alt="rating" />
        <img src={star} className="star" alt="rating" />
        <img src={star} className="star" alt="rating" />
        <img src={star} className="star" alt="rating" />
        </div>
        </div>
    );
}

export default Product;