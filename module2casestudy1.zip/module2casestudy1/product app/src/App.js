import React from 'react';
import Product from "./Product";
import './App.css';
import laptop from "./images/laptop.png";
import phone from "./images/phone.png";
import headphone from "./images/headphone.png";
import watch from "./images/watch.png";
import tablet from "./images/tablet.png";
import speaker from "./images/speaker.png";
import console from "./images/console.png";
import monitor from "./images/monitor.png";
import mouse from "./images/mouse.png";
import keyboard from "./images/keyboard.png";

function App() {
  const products = [
    { id: 1, name: "Laptop", price: 999, description: "A high-performance laptop.", img: laptop },
    { id: 2, name: "Smartphone", price: 699, description: "A latest model smartphone.", img: phone },
    { id: 3, name: "Headphones", price: 199, description: "Noise-cancelling headphones.", img: headphone },
    { id: 4, name: "Smartwatch", price: 199, description: "A smartwatch with fitness tracking.", img: watch },
    { id: 5, name: "Tablet", price: 499, description: "A lightweight tablet for productivity.", img: tablet },
    { id: 6, name: "Bluetooth Speaker", price: 149, description: "Portable Bluetooth speaker.", img: speaker },
    { id: 7, name: "Gaming Console", price: 299, description: "Next-gen gaming console.", img: console },
    { id: 8, name: "4K Monitor", price: 399, description: "High-resolution 4K monitor.", img: monitor },
    { id: 9, name: "Wireless Mouse", price: 49, description: "Ergonomic wireless mouse.", img: mouse },
    { id: 10, name: "Mechanical Keyboard", price: 89, description: "A keyboard for gamers & typists.", img: keyboard }
  ];
  return(
    <div className='main-container'>

      <div className='section-title'>
        <div className='red-bar'></div>
        <span>Our Product</span>
      </div>

      <h1 className='big-heading'>Explore Our products</h1>

      <div className='product-grid'>
        {products.map((p) =>(
          <Product key={p.id} {...p}/>
        ))}
      </div>
    </div>
  );
}
export default App;
